from pydiceplot.plots._plot import dice_plot, domino_plot
from ._backend import set_backend
